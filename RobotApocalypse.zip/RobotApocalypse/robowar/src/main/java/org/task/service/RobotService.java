package org.task.service;

import org.task.dto.RobotDto;

import java.util.List;

public interface RobotService {
    List<RobotDto> getRobotData();
}
